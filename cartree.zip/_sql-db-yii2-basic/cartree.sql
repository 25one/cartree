-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 05, 2018 at 11:31 AM
-- Server version: 5.5.61-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `yii2-basic`
--

-- --------------------------------------------------------

--
-- Table structure for table `cartree`
--

CREATE TABLE IF NOT EXISTS `cartree` (
  `id` int(12) NOT NULL,
  `parent_id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cartree`
--

INSERT INTO `cartree` (`id`, `parent_id`, `name`) VALUES
(1, 0, 'Germany'),
(2, 0, 'Italy'),
(3, 0, 'France'),
(4, 1, 'WV'),
(5, 1, 'Opel'),
(6, 2, 'Fiat'),
(7, 2, 'Alfa Romeo'),
(8, 3, 'Renault'),
(9, 3, 'Peugeot'),
(10, 0, 'USA'),
(11, 0, 'Japan'),
(12, 10, 'Chevrolet'),
(13, 10, 'Ford'),
(14, 11, 'Mazda'),
(15, 11, 'Honda'),
(16, 0, 'China'),
(17, 16, 'BYD'),
(18, 16, 'Geely');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
