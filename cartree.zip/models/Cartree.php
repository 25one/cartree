<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

class Cartree extends ActiveRecord
{

    public $checkbox = true;

}
